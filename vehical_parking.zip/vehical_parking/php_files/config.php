<?php 
    include "database.php";

    $base_url = "http://localhost/vehicle-parking-yb/";
?>